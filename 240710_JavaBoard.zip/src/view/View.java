package view;

public enum View {
	MAIN,					// 기본화면
	ADMIN,
	LOGIN,
	FREE_BOARD,
	QNA_BOARD,
	BOARD_INSERT,
	BOARD_LIST,
	BOARD_DETAIL,
	BOARD_UPDATE,
	BOARD_DELETE,
	QNA_BOARD_INSERT,
	QNA_BOARD_LIST

}
